const apiBase = API_BASE_URL.replace(/\/$/, "");
const $ = id => document.getElementById(id);

async function api(path, options = {}) {
    const response = await fetch(`${apiBase}${path}`, options);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || `Request failed: ${response.status}`);
    return data;
}

function setConnection(status, text) {
    const badge = $("connectionBadge");
    badge.className = `badge ${status}`;
    badge.textContent = text;
}

async function loadDashboard() {
    setConnection("loading", "Connecting...");
    try {
        const [health, status, services, stats] = await Promise.all([
            api("/api/health"), api("/api/status"), api("/api/services"), api("/api/stats")
        ]);

        setConnection("success", "Backend Connected");
        $("statusValue").textContent = health.status;
        $("statusHost").textContent = `Host: ${health.hostname}`;
        $("serverValue").textContent = status.status;
        $("environmentValue").textContent = `${health.environment} • ${status.hostname}`;
        $("servicesValue").textContent = services.services.length;
        $("requestsValue").textContent = stats.requests;

        $("healthResult").innerHTML =
            `<span class="dot"></span>Backend healthy • ${health.timestamp}`;

        $("servicesList").innerHTML = services.services.map(service => `
            <div class="service-row">
              <div><strong>${escapeHtml(service.name)}</strong><small>${escapeHtml(service.type)}</small></div>
              <span class="service-status">${escapeHtml(service.status)}</span>
            </div>`).join("");
    } catch (error) {
        setConnection("error", "Backend Offline");
        $("healthResult").innerHTML =
            `<span class="error-text">Cannot connect to backend. Check API_BASE_URL and make sure Flask is running.</span>`;
        $("servicesList").innerHTML = `<div class="empty">Backend unavailable.</div>`;
    }
}

async function generateLoad() {
    const duration = $("duration").value;
    const button = $("loadBtn");
    const result = $("loadResult");

    button.disabled = true;
    button.textContent = "Generating...";
    result.className = "result";
    result.textContent = `Generating ${duration}s CPU workload...`;

    try {
        const data = await api(`/api/load?seconds=${duration}`);
        result.innerHTML =
            `<strong>Load completed.</strong> Duration: ${data.duration_seconds}s | Operations: ${data.operations.toLocaleString()} | Host: ${escapeHtml(data.hostname)}`;
    } catch (error) {
        result.textContent = `Load request failed: ${error.message}`;
    } finally {
        button.disabled = false;
        button.textContent = "Generate Load";
    }
}

function escapeHtml(value) {
    return String(value).replaceAll("&","&amp;").replaceAll("<","&lt;")
        .replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
}

$("refreshBtn").addEventListener("click", loadDashboard);
$("loadBtn").addEventListener("click", generateLoad);
loadDashboard();
