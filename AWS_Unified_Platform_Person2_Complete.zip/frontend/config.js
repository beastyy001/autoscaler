// Change this URL after AWS deployment.
// Local backend:
const API_BASE_URL = window.API_BASE_URL || "http://localhost:5000";
