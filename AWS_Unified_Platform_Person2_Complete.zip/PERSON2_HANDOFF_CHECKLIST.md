# Person 2 Handoff Checklist

## Application
- [ ] Backend starts
- [ ] Frontend opens
- [ ] `/api/health` works
- [ ] `/api/status` works
- [ ] `/api/services` works
- [ ] `/api/stats` works
- [ ] `/api/load?seconds=1` works
- [ ] Generate Load button works
- [ ] No browser console errors

## Docker
- [ ] `docker compose up --build` works
- [ ] Frontend opens on port 8080
- [ ] Backend opens on port 5000

## Documentation
- [ ] README included
- [ ] API documentation included
- [ ] `.env.example` included
- [ ] No secrets committed

## Person 1 receives
The entire repository.

Important:
- backend port = 5000
- frontend port in Docker = 8080
- backend entry point = `app:app`
- load endpoint = `/api/load?seconds=5`
- frontend API URL = `frontend/config.js`

## Person 3 receives
API endpoint list and the `/api/load` endpoint for Locust testing.
