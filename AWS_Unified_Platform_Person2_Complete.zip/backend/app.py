from flask import Flask, jsonify, request
from flask_cors import CORS
import os, time, math, socket
from datetime import datetime, timezone

app = Flask(__name__)
CORS(app)

APP_NAME = os.getenv("APP_NAME", "AWS Unified Auto-Scaling Platform")
ENVIRONMENT = os.getenv("ENVIRONMENT", "development")

def utc_now():
    return datetime.now(timezone.utc).isoformat()

@app.get("/")
def home():
    return jsonify({
        "application": APP_NAME,
        "message": "Backend is running",
        "environment": ENVIRONMENT,
        "health": "/api/health"
    })

@app.get("/api/health")
def health():
    return jsonify({
        "status": "healthy",
        "application": APP_NAME,
        "environment": ENVIRONMENT,
        "timestamp": utc_now(),
        "hostname": socket.gethostname()
    })

@app.get("/api/status")
def status():
    return jsonify({
        "status": "running",
        "service": "backend-api",
        "hostname": socket.gethostname(),
        "timestamp": utc_now()
    })

@app.get("/api/services")
def services():
    return jsonify({"services": [
        {"name": "Web Application", "status": "Running", "type": "Frontend"},
        {"name": "Backend API", "status": "Running", "type": "REST API"},
        {"name": "Auto Scaling", "status": "Configured", "type": "AWS"},
        {"name": "Monitoring", "status": "Configured", "type": "CloudWatch"}
    ]})

@app.get("/api/stats")
def stats():
    return jsonify({
        "requests": 0,
        "active_users": 0,
        "server_status": "Healthy",
        "environment": ENVIRONMENT,
        "hostname": socket.gethostname(),
        "timestamp": utc_now(),
        "note": "Request metrics are collected by AWS/CloudWatch after deployment."
    })

@app.get("/api/load")
def generate_load():
    try:
        seconds = float(request.args.get("seconds", 5))
    except ValueError:
        return jsonify({"error": "seconds must be a number"}), 400

    seconds = max(1, min(seconds, 15))
    end_time = time.perf_counter() + seconds
    operations = 0
    value = 0.0

    while time.perf_counter() < end_time:
        for i in range(1, 5000):
            value += math.sqrt(i) * math.sin(i)
            operations += 1

    return jsonify({
        "status": "completed",
        "duration_seconds": round(seconds, 2),
        "operations": operations,
        "result_sample": round(value, 4),
        "hostname": socket.gethostname(),
        "timestamp": utc_now(),
        "message": "Controlled CPU workload completed."
    })

@app.errorhandler(404)
def not_found(_error):
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(500)
def internal_error(_error):
    return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)
