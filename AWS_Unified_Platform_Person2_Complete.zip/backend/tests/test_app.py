import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import app

def test_health():
    r = app.test_client().get("/api/health")
    assert r.status_code == 200
    assert r.json["status"] == "healthy"

def test_status():
    r = app.test_client().get("/api/status")
    assert r.status_code == 200

def test_services():
    r = app.test_client().get("/api/services")
    assert r.status_code == 200
    assert len(r.json["services"]) >= 1

def test_stats():
    r = app.test_client().get("/api/stats")
    assert r.status_code == 200
    assert "server_status" in r.json

def test_load():
    r = app.test_client().get("/api/load?seconds=1")
    assert r.status_code == 200
    assert r.json["status"] == "completed"

def test_unknown_route():
    r = app.test_client().get("/does-not-exist")
    assert r.status_code == 404
