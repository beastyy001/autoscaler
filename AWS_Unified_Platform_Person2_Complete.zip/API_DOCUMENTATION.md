# API Documentation

Local base URL: `http://localhost:5000`

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Backend health check |
| GET | `/api/status` | Service/server status |
| GET | `/api/services` | Platform service list |
| GET | `/api/stats` | Dashboard statistics |
| GET | `/api/load?seconds=5` | Controlled CPU workload |

## Load endpoint

Use:

`GET /api/load?seconds=5`

Allowed duration: **1–15 seconds**.

The response includes the backend hostname, useful for demonstrating requests reaching different instances after AWS scaling.

## AWS handoff

Backend port: `5000`

Gunicorn entry point: `app:app`

Frontend API URL: `frontend/config.js`

Do not put AWS keys, passwords, or production secrets in this repository.
