# AWS Unified Auto-Scaling Platform — Person 2 Package

This is the **Application + Frontend** package for Project Exhibition-I.

## Included

- Flask REST backend
- Unified HTML/CSS/JavaScript dashboard
- Controlled CPU load endpoint
- Dockerfiles
- Docker Compose
- Backend tests
- API documentation
- Environment configuration

## Run backend locally

```bash
cd backend
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
```

Then:

```bash
pip install -r requirements.txt
python app.py
```

Backend: `http://localhost:5000`

Health: `http://localhost:5000/api/health`

## Run frontend locally

From the project root:

```bash
cd frontend
python -m http.server 5500
```

Open: `http://localhost:5500`

The frontend calls `http://localhost:5000` by default.

## Run everything with Docker

From the project root:

```bash
docker compose up --build
```

Frontend: `http://localhost:8080`

Backend: `http://localhost:5000`

Stop:

```bash
docker compose down
```

## Run tests

```bash
pip install -r backend/requirements.txt
pytest backend/tests
```

## Handoff to Person 1

1. Deploy backend on the final AWS compute platform.
2. Backend listens on port `5000`.
3. Gunicorn entry point is `app:app`.
4. Update `frontend/config.js` with the final AWS API URL.
5. Use `/api/load?seconds=5` for the controlled CPU-load demonstration.
6. Backend returns hostname information to help demonstrate multiple instances.

## Handoff to Person 3

Use `/api/load?seconds=5` for Locust load generation.

Use `/api/health`, `/api/status`, and `/api/stats` for lightweight traffic.

## Security

Never commit AWS access keys, secret keys, passwords, or production secrets. Use environment variables and AWS secret-management services during deployment.

## Current limitation

Dashboard request counts are placeholder values. Real infrastructure metrics should come from CloudWatch after AWS deployment.
